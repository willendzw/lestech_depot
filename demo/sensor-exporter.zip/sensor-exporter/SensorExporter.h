#pragma once
#include "Uart.h"
#include "UdpObject.h"

class SensorExporter
{
public:
    SensorExporter();

    void run(void);

private:
    void uartRecvTask();
    void uartResetTask();
private:
    UdpClient m_client;
    Uart m_uart;    
    char uartRecvBuffer[65536];
};
