#include <cstring>
#include <iostream>

#include "UdpObject.h"
#include "DataProtocol.h"
#include "SensorExporter.h"

using namespace std;

int main()
{
    char szBuffer[128] = { 0 };

#if 0
    UdpServer server;
    server.SetParameter(60001);

    {
        UdpClient client;
        client.SetParameter(60001, "127.0.0.1");


        std::strcpy(szBuffer, "abcedfe");
        std::cout << "Client Send: " << szBuffer << std::endl;
        client.SendTo(szBuffer, std::strlen(szBuffer));


        memset(szBuffer, 0, sizeof(szBuffer));
        server.ReceiveFrom(szBuffer, sizeof(szBuffer));
        std::cout << "Server Receive : " << szBuffer << std::endl;


        std::strcpy(szBuffer, "daaaaaaaaaaaaaaaaa");
        std::cout << "Server Send: " << szBuffer << std::endl;
        server.SendTo(szBuffer, std::strlen(szBuffer));


        memset(szBuffer, 0, sizeof(szBuffer));
        client.ReceiveFrom(szBuffer, sizeof(szBuffer));
        std::cout << "Client Receive : " << szBuffer << std::endl;

        std::cout << client.IsConnect() << std::endl;
    }
#else
    SensorExporter exporter;
    exporter.run();
#endif

    return 0;
}