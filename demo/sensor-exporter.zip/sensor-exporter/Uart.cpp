#include "Uart.h"

#include <errno.h>
#include <fcntl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Uart::Uart():
    m_fd(-1)
{

}

Uart::~Uart()
{
    closeUart();
}

int Uart::openUart(string dev)
{
    m_devName = dev;
    m_fd = open(dev.c_str(), O_RDWR | O_NOCTTY | O_SYNC );
    if (m_fd < 0) {
        printf("Error opening %s: %s\n", dev.c_str(), strerror(errno));
        return -1;
    }
    return m_fd;
}

int Uart::closeUart()
{
    if (m_fd >= 0) {
        close(m_fd);
        m_fd = -1;
    }

    return 0;
}

int Uart::receive(const char *buff, int max)
{
    if (m_fd <= 0) {
        printf("device does not open.\n");
        return -1;
    }
    return read(m_fd, (void *)buff, max);
}


int Uart::send(const char *buff, int len)
{
    if (m_fd <= 0) {
        printf("device does not open.\n");
        return -1;
    }

    return write(m_fd, (void*)buff, len);
}

int Uart::setAttribute(int speed, int minCount)
{
    //set rate and other normal params
    {
        struct termios tty;

        if (tcgetattr(m_fd, &tty) < 0) {
            printf("Error from tcgetattr: %s\n", strerror(errno));
            return -1;
        }

        cfsetospeed(&tty, (speed_t)speed);
        cfsetispeed(&tty, (speed_t)speed);

        tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
        tty.c_cflag &= ~CSIZE;
        tty.c_cflag |= CS8;         /* 8-bit characters */
        tty.c_cflag &= ~PARENB;     /* no parity bit */
        tty.c_cflag &= ~CSTOPB;     /* only need 1 stop bit */
        tty.c_cflag &= ~CRTSCTS;    /* no hardware flowcontrol */

        /* setup for non-canonical mode */
        tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
        tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
        tty.c_oflag &= ~OPOST;

        /* fetch bytes as they become available */
        tty.c_cc[VMIN] = minCount;
        tty.c_cc[VTIME] = 0;

        if (tcsetattr(m_fd, TCSANOW, &tty) != 0) {
            printf("Error from tcsetattr: %s\n", strerror(errno));
            return -1;
        }        
    }
}
