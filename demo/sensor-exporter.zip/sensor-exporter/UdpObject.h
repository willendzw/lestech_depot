#pragma once
#ifndef __C_UDP_OBJECT_H__
#define __C_UDP_OBJECT_H__

#include <string>

#ifdef OS_PLATFORM_WIN

#include <WinSock2.h>
#pragma comment(lib, "ws2_32.lib")

#else

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include <sys/un.h>  
//#include <netdb.h>

#endif // !OS_PLATFORM_WIN

class UdpObject
{
protected:
    UdpObject();
    virtual ~UdpObject();

public:
    virtual void SetParameter(int nPort, const char* szAddress = nullptr);

public:
    virtual int SendTo(const char* szData, int nDataLength);
    virtual int ReceiveFrom(char* szBuffer, int nBufferSize);

public:
    virtual const std::string& ToString() = 0;

protected:
    virtual struct sockaddr_in& SocketAddress();

protected:
#ifdef OS_PLATFORM_WIN
    SOCKET m_sktUdpObject;
#else
    int m_sktUdpObject;
#endif // !OS_PLATFORM_WIN
    struct sockaddr_in m_sktUdpObjectAddress = { 0 };
    volatile int m_nLastSendTransferred = 0;
    volatile int m_nLastReceiveTransferred = 0;

private:
    int m_nPort = 0;
    char m_szAddress[32] = { 0 };

private:
    UdpObject(const UdpObject&);
    UdpObject& operator=(const UdpObject&);
};


class UdpClient : public UdpObject
{
public:
    UdpClient() 
    { 
        m_strEndPoint = "C:" + std::to_string(m_sktUdpObject); 
        printf("ctor %s.\r\n", ToString().c_str());
    };
    virtual ~UdpClient() 
    { 
        printf("dctor %s.\r\n", ToString().c_str()); 
    };

public:
    virtual bool IsConnect();

public:
    virtual const std::string& ToString() override;

private:
    std::string m_strEndPoint;

private:
    UdpClient(const UdpClient&);
    UdpClient& operator=(const UdpClient&);
};


//Single Client
class UdpServer : public UdpObject
{
public:
    UdpServer() 
    { 
        m_strEndPoint = "S:" + std::to_string(m_sktUdpObject);
        printf("ctor %s.\r\n", ToString().c_str());
    };
    virtual ~UdpServer() 
    { 
        printf("dctor %s.\r\n", ToString().c_str()); 
    };

public:
    void SetParameter(int nPort, const char* szAddress = nullptr) override;

public:
    struct sockaddr_in & SocketAddress() override;

public:
    virtual const std::string& ToString() override;

private:
    struct sockaddr_in m_sktAddressClient = { 0 };

private:
    std::string m_strEndPoint;

private:
    UdpServer(const UdpServer&);
    UdpServer& operator=(const UdpServer&);
};

#endif // !__C_UDP_OBJECT_H__