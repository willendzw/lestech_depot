#pragma once
#include <stdlib.h>
#include <iostream>

const unsigned short magic = 0x5554;

// endian? 对端是stm32， 正常情况下是小端
//pack? 从接口协议上看是1字节对齐
#pragma pack(push)
#pragma pack(1)

typedef struct __head
{
    unsigned short magic;
    unsigned char order;
    unsigned short len;
    unsigned char check;
} Head;
const unsigned short HeadSize = sizeof(Head);
typedef struct __sensor_data
{
    Head head;
    char message[0];
} SensorData;
#pragma pack(pop)