#! /bin/sh

#
dirBuildShell="./temp/"

#
if [ -d "${dirBuildShell}" ]; then
    rm -rf "${dirBuildShell}"
fi

#
if [ $# -ge 1 ]; then   
    dirBuildShell="../$1/"
    rm -rf "${dirBuildShell}"
fi

#
if [ ! -d "${dirBuildShell}" ]; then
    mkdir "${dirBuildShell}"
    cd "${dirBuildShell}"
fi

#
cmake ../ && make