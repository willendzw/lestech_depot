#pragma once
#include <stdlib.h>
#include <iostream>
#include <termios.h>
#include <unistd.h>

using namespace std;

class Uart
{
public:
    Uart();
    ~Uart();

    int openUart(string dev);
    int closeUart();
    int receive(const char *buff, int max);
    int send(const char *buff, int len);

    int setAttribute(int speed, int minCount);

private:
    std::string m_devName;
    int m_fd;
};