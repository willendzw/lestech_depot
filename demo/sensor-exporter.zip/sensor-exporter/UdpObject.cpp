#include "UdpObject.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>


UdpObject::UdpObject()
{
#ifdef OS_PLATFORM_WIN
    WSADATA stData;
    WSAStartup(MAKEWORD(2, 2), &stData);
#else
#endif // !OS_PLATFORM_WIN

    m_sktUdpObject = socket(AF_INET, SOCK_DGRAM, 0/*IPPROTO_UDP, IPPROTO_UDPLITE*/);
}
UdpObject::~UdpObject()
{
#ifdef OS_PLATFORM_WIN
    closesocket(m_sktUdpObject);
    WSACleanup();
#else
    //shutdown(m_sktUdpObject, SHUT_RDWR);
    close(m_sktUdpObject);
#endif // !OS_PLATFORM_WIN
}

void UdpObject::SetParameter(int nPort, const char* szAddress)
{
    m_nPort = nPort;

    m_sktUdpObjectAddress.sin_family = AF_INET;
    m_sktUdpObjectAddress.sin_port = htons(m_nPort);

    if (nullptr != szAddress)
    {
        std::strcpy(m_szAddress, szAddress);
        m_sktUdpObjectAddress.sin_addr.s_addr = inet_addr(m_szAddress);
    }
    else
    {
        m_sktUdpObjectAddress.sin_addr.s_addr = INADDR_ANY;
    }
}

struct sockaddr_in& UdpObject::SocketAddress()
{
    return m_sktUdpObjectAddress;
}

int UdpObject::SendTo(const char* szData, int nDataLength)
{
    struct sockaddr_in& sktAddress = SocketAddress();

#ifdef OS_PLATFORM_WIN
    int nSktAddressSize = sizeof(sktAddress);
#else
    socklen_t nSktAddressSize = sizeof(sktAddress);
#endif // !OS_PLATFORM_WIN

    m_nLastSendTransferred = sendto(m_sktUdpObject, szData, nDataLength, 0, (const struct sockaddr*)&sktAddress, sizeof(sktAddress));

    return m_nLastSendTransferred;
}

int UdpObject::ReceiveFrom(char* szBuffer, int nBufferSize)
{
    struct sockaddr_in& sktAddress = SocketAddress();

#ifdef OS_PLATFORM_WIN
    int nSktAddressSize = sizeof(sktAddress);
#else
    socklen_t nSktAddressSize = sizeof(sktAddress);
#endif // !OS_PLATFORM_WIN

    m_nLastReceiveTransferred = recvfrom(m_sktUdpObject, szBuffer, nBufferSize, 0, (struct sockaddr*)&sktAddress, &nSktAddressSize);

    return m_nLastReceiveTransferred;
}



bool UdpClient::IsConnect()
{
    return m_nLastSendTransferred >= 0 || m_nLastReceiveTransferred >= 0;
}

const std::string& UdpClient::ToString()
{
    return m_strEndPoint;
}


void UdpServer::SetParameter(int nPort, const char* szAddress)
{
    UdpObject::SetParameter(nPort, nullptr);

    bind(m_sktUdpObject, (const struct sockaddr*)&m_sktUdpObjectAddress, sizeof(m_sktUdpObjectAddress));
}

struct sockaddr_in& UdpServer::SocketAddress()
{
    return m_sktAddressClient;
}

const std::string& UdpServer::ToString()
{
    return m_strEndPoint;
}