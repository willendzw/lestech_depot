#include "SensorExporter.h"
#include "DataProtocol.h"

#include <unistd.h>

void SensorExporter::uartResetTask()
{
    int magicRecevied = 0;
	uint32_t expectedLength = 2;
	uint32_t receivedLength = 0;
	while (1)
	{
        int len = 0;
        if (magicRecevied)
            break;

        len = m_uart.receive(uartRecvBuffer + receivedLength, expectedLength - receivedLength);
        if (len > 0)
        {
            receivedLength += len;
        }
        if (receivedLength == expectedLength)
        {
            SensorData *sensor = (SensorData *)uartRecvBuffer;
            if (sensor->head.magic == magic)
            {
                magicRecevied = 1;
            }
            else
            {
                expectedLength = 2;
                receivedLength = 0;
            }
            
        }
    }
}

void SensorExporter::uartRecvTask()
{
	int headerRecevied = 0;
	uint32_t expectedLength = 0;
	uint32_t receivedLength = 0;

	int uartRecvNeedClear = 1;
	while (1)
	{
		int len = 0;

		if (uartRecvNeedClear) {
			uartRecvNeedClear = 0;
			headerRecevied = 0;
			expectedLength = 0;
			receivedLength = 0;
		}

		if (!headerRecevied)
		{
			if (expectedLength == 0)
			{
				expectedLength = HeadSize;
				receivedLength = 0;
			}
            len = m_uart.receive(uartRecvBuffer + receivedLength, expectedLength - receivedLength);
			if (len > 0)
			{
				receivedLength += len;
			}
			if (receivedLength == expectedLength)
			{
                SensorData *sensor = (SensorData *)uartRecvBuffer;
                if (sensor->head.magic == magic) 
                {
                    headerRecevied = 1;
                    expectedLength = sensor->head.len + 5;   //6-1
                }
                else
                {
                    std::cout<<"magic error"<<std::endl;;
                    uartResetTask();
                    receivedLength = 2;
                    std::cout<<"magic received"<<std::endl;;
                }
                
			}
		}
		else
		{
			len = m_uart.receive((const char*)(uartRecvBuffer + receivedLength), expectedLength - receivedLength);
			if (len > 0)
			{
				receivedLength += len;
			}
			if (receivedLength == expectedLength)
			{
				static int count = 0;
				count++;
				SensorData *sensor = (SensorData *)uartRecvBuffer;
				printf("receive packet:%d, len=%d, content=%s\n", count, expectedLength, sensor->message);
				m_client.SendTo((const char*)uartRecvBuffer, expectedLength);
				headerRecevied = 0;
				expectedLength = 0;
				receivedLength = 0;
			}
		}

        // block mode , no need sleep
        #if 0
		if (len <= 0)
		{
            usleep(100000);
		}
        #endif
	}
}

SensorExporter::SensorExporter()
{
    m_uart.openUart("/dev/ttysWK2");
    m_uart.setAttribute(B9600, 1);
    m_client.SetParameter(60001, "127.0.0.1");
}

void SensorExporter::run()
{
    uartRecvTask();
}